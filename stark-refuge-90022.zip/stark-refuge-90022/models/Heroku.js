const mongoose = require('mongoose'); //importing Mongoose into the file
const Schema = mongoose.Schema;
// schema is a template / blueprint for your db; consists of the properties in your db and it's details

// mongoose gives you functions so that you can easily add, update and delete stuff in the database

// these fields should be within the form in your front-end
// if there are additional fields in the front-end, which are not added to the back-end here, then that data cannot be input into db. 
const HerokuSchema = new Schema({
	name: {
		type: String,
		required: false
	},
	email: {
		type: String,
		required: true
	},
	password: {
		type: String,
		required: true
	},
	createdAt: { //first word lower case, and second word uppercase -- best practice
		type: Date,
		default: Date.now
	}
});

//if you want this file accessible by others within this folder, export it at the bottom of the file
module.exports = Heroku = mongoose.model('herokus', HerokuSchema);

