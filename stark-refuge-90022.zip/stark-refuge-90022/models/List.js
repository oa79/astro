const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const Task = require('../models/Task');

const ListSchema = new Schema({
  name: {
    type: String,
    required: false
  },
  user: { // so the database remembers this list belongs to this user
    type: Schema.ObjectId, ref: 'user', // not storing all the users information, rather, only his ID
    select: false,
  },
  tasks: [{
    type: Task.schema
  }],
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = List = mongoose.model('lists', ListSchema);