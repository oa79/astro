// https://github.com/minhajkk/bawn
	// Step 1: https://gist.github.com/minhajkk/dfd8cbda01a7002c1395aa540e4f9b1d
	// Step 3: https://gist.github.com/minhajkk/9f653debb53cd39ca6e9b44c69363760
	// Step 4:https://gist.github.com/minhajkk/585b1a0dbef85a7ae3dd1e48a0af8f58

	// server.js: https://gist.github.com/minhajkk/9dc77a44b66ddf27bffc475959bae208

// create a Heroku account
// download Heroku CLI: https://devcenter.heroku.com/articles/heroku-cli#other-installation-methods
// create your app, and follow instructions here thereafter: https://dashboard.heroku.com/apps/astrolabs-dubai/deploy/heroku-git

// heroku create
// heroku login
// git init
// heroku git:remote -a stark-refuge-90022
// git add .
// git commit -am "make it better"
// git push heroku master
const express = require('express');
const mongoose = require('mongoose');
const passport = require('passport'); //calling the dependency, not the file -- Passport is an authentication middleware for Node.js | Passport can be unobtrusively dropped in to any Express-based web application | A comprehensive set of strategies support authentication using a username and password, Facebook, Twitter and more
// const bcrypt = require('bcrypt'); // the bcrypt library in NPM is used to hash password makes it really easy to hash and compare passwords in Node
const bcrypt = require('bcryptjs'); // the bcrypt library in NPM is used to hash password makes it really easy to hash and compare passwords in Node
const jwt = require('jsonwebtoken');
const Heroku = require('./models/Heroku');
const Key = require('./config/keys');
const bodyParser = require('body-parser'); //important for POSTs and Puts - without which those functions won't work

const app = express();


// Body parser middleware
app.use(express.urlencoded({ extended: false }));
app.use(bodyParser.json());

const db = Key.mongoURI;

mongoose // we're chaining 3 methods
	.connect(db, { useNewUrlParser: true }) //connect database | (useNewUrlParser) tells the database that we will be using a string to connect to the database
	.then( () => console.log('Connected to database')) //if database is connected, console this meessage
	.catch( err => console.log(err)); //if database does not connect, console this error

// NOTE: I had DB connection issues, and this was the error: "Error: queryTxt ETIMEOUT...". This hero told me what that meant: 
	//Hi @cashFLO960 the error Error: connect ETIMEDOUT is from the Node.js networking code. It means that a TCP connection could not be established to your MySQL server. Usually this is a networking or firewall issue.
	// then I used VPN to connect to office and I connected to my DB immediately
	// first thing first Omar, ALWAYS understand the issue clearly, then try solutions. Once the problem is understood well, often times the answer / solution is the easy bit


// Init passport | should be initialized AFTER the DB
app.use(passport.initialize());
require('./config/passport')(passport);


//----------

app.get('/', (req,res) => res.json({
	msg: "Hello! Welcome to BAWN(Backend API with NodeJS)"
}));

const usersRouter = require('./routes/users');
app.use('/users', usersRouter);

const listsRouter = require('./routes/lists');
app.use('/users/lists', listsRouter);

// const tasksRouter = require('./routes/tasks');
// app.use('/users/tasks', tasksRouter);

// --------------

// app.get('/', (req,res) => res.json({
// 	msg: "Hello! Welcome to BAWN(Backend API with NodeJS)"
// }));

// app.post('https://stark-refuge-90022.herokuapp.com/users', (req,res) => {
// 	const newUser = new Heroku({
// 		name: req.body.name,
// 		email: req.body.email,
// 		password: req.body.password
// 	});
// 	newUser.save()
// 		.then( () => console.json("new user is saved"))
// 		.then(user => res.json(user))
// 		.catch(err => err => console.log(err));
// 		// .then(user => res.json(err));
// });

// app.get('https://stark-refuge-90022.herokuapp.com/users', (req,res) => {
// 	Heroku.find({})
// 	.then(data => {
// 		res.json(data);
// 	})
// });

// ---------

//this should be right at the end, before port
app.get('*', (req, res) => {
	res.send('404');
});

const port = process.env.PORT || 5000;
app.listen(port, () => console.log(`Server running on port ${port}`));
