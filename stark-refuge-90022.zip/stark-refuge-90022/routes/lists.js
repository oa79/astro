const express = require('express');
const passport = require('passport'); 
const Task = require('../models/Task');
const List = require('../models/List');

const router = express.Router();


// * Create a new List of a logged in User
router.post('/', passport.authenticate('jwt', {session: false}), (req,res) => {
	new List({
		name: req.body.name, // in POSTMAN, we only pass the NAME of the list we would like to create, and that particular user's Authorization BEARER TOKEN
		user: req.user,
		tasks: []
	})
	.save()
	.then(list => res.json({id: list.id}))
	.catch(err => console.log(err));
});


/**
 * Get whole list of todo list
   -- you need to get the bearer token, which can be found with fetching data from users/login
   -- once you've got that bearer token, input that into the authorizatioon field, and then you can use 'user' in body to pick up the lists associatedd with a particular user
 */


// ONLY pass a particular user's bearer token (nothing in Body), and do a GET request at /users/lists and you should be able to retrieve all of the lists you've created associated with that user
// * GET all of the Lists of a logged in User
router.get('/', passport.authenticate('jwt', { session: false }), (req, res) => {
    List.find({user: req.user})
      .then(list => res.json(list))
      .catch(err => console.log(err));
});


// POST tasks by List ID. Keep in mind that a user may have multiple lists, so you have to pass the ID of that particular List of that particular User
// * Create Tasks within a List:
router.post('/:id/tasks', passport.authenticate('jwt', { session: false }), (req, res) => {
    List.findById(req.params.id)
      .then(list=> {
        const task = new Task({
        	taskName: req.body.taskName
        })
        list.tasks.push(task);
        list.save()
          .then(list => res.json(list))
          .catch(err => console.log(err));
      })
      .catch(err => console.log(err));
});


// * GET all the Tasks within a particular list, by passing the ID of a particular List
router.get('/:id/tasks', passport.authenticate('jwt', { session: false }), (req, res) => {
    List.find({'_id': req.params.id, user: req.user})
        .then(list => res.json(list))
        .catch(err => console.log(err));
});


module.exports = router;