const express = require('express');
const passport = require('passport'); 
// const bcrypt = require('bcrypt');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const Heroku = require('../models/Heroku');
const Key = require('../config/keys');

const bodyParser = require('body-parser'); //important for POSTs and Puts - without which those functions won't work
const router = express.Router();

// Body parser middleware
router.use(express.urlencoded({ extended: false }));
router.use(bodyParser.json());

// router.get('/', (req,res) => {
//     Heroku.find({})
//     .then(data => {
//         res.json(data);
//     })
// });

router.get('/', (req, res) => {
    Heroku.find()
        .then(users => res.json(users))
        .catch(err => console.log(err))
});

router.post('/register', (req,res) => {
  Heroku.findOne({ email: req.body.email }).then(user => {
    if (user) {
        return res.status(400).json({ email: "Email already exists" });
    } 
    else {
        const newUser = new Heroku({
            name: req.body.name,
            email: req.body.email,
            password: req.body.password
        });

        bcrypt.genSalt(10, (err, salt) => {
            bcrypt.hash(newUser.password, salt, (err, hash) => {
              if (err) throw err;
              newUser.password = hash;
              newUser.save()
                .then( () => console.json("new user is saved"))
                .then(user => res.json(user))
                .catch(err => err => console.log(err));
                // .then(user => res.json(err));
            });
        });
    }
  });
});

router.post('/login', (req, res) => {
    const email = req.body.email;
    const password = req.body.password;

    Heroku.findOne({ email }).then(user => {
        if (!user) {
            return res.status(400).json({ email: "User account does not exist" });
        } 
        else {
          console.log(user);
          console.log('hello');
            bcrypt.compare(password, user.password).then(isMatch => {
                if (isMatch) {
                    const payload = { id: user.id, name: user.name };

                    // Sign Token
                    jwt.sign(
                        payload, 
                        Key.secret, { expiresIn: 3600 },
                        // Key.secret, { expiresIn: 3600 }, // the token expires in 3600ms and rightfully so, because we don't want a hashed password available to us in the front-end. However, we can pass the token in a variable and call it to fetch user data
                        (err, token) => {
                            res.json({
                                success: true,
                                token: 'Bearer ' + token,
                                name: user.name,
                                // email: email
                            });
                        }
                    );
                } else {
                    return res.status(400).json({ email: "Password is invalid" });
                }
            })
        }
    })
});

// this will pull up the id, name, email, password, and created at of a particular user, whose token you pass in Authorization so it is part of your header, and the name of the user e.g. Robin
router.get('/me', passport.authenticate('jwt', {session: false}), (req, res) => {
  return res.json({"me": req.user})
});

module.exports = router;