// good for when you are running your application locally

module.exports = {
	secret: "worstKeptSecret",
	mongoURI: "mongodb+srv://admin01:12345@cluster0-gusad.mongodb.net/astrolabs?retryWrites=true"
}


// we used to have our DB string explicitly written in our server.js, but now we can write: const db = Keys.mongoURI
// we used to have our Secret explicitly written in Passport.js, and in our /users/login route, but now we've replaced it with Keys.secret

// however, you never want to store senstive info in a file on a live server / on production
// rather, you want to retrieve that info from a remote file


// Lets create another file in order to automate this e.g. look at X file when we are working locally, and look at Y file when we're in Production