module.exports = {
	secret: process.env.secret,
	mongoURI: process.env.mongoURI
}

	// secret: process.env.secret,
	// mongoURI: process.env.mongoURI



// I set-up the deets at https://dashboard.heroku.com/apps/stark-refuge-90022/settings
// After you add the deets, make a couple of changes in your files and do another git push
// - heroku login
// - git add .
// - git commit -am "make it better"
// - git push heroku master


// we used to have our DB string explicitly written in our server.js, but now we can write: const db = Keys.mongoURI
// we used to have our Secret explicitly written in Passport.js, and in our /users/login route, but now we've replaced it with Keys.secret

// the Secret and MongoURI needs to be configured in Heroku for this to work (or whatever server you are running on)