if (process.env.NODE_ENV === 'production') {
	console.log("Env is production")
	module.exports = require('./keys_prod')
} 
else {
	console.log("Env is development")
	module.exports = require('./keys_dev')
}

// We use this file to give instructions to the program to:
// 1. look at keys_prod.js IF we are working in production
// 2. ELSE, look at keys_dev. js if we're working locally

// we used to have our DB string explicitly written in our server.js, but now we can write: const db = Keys.mongoURI
// we used to have our Secret explicitly written in Passport.js, and in our /users/login route, but now we've replaced it with Keys.secret